export default {
    icDropDown: require('../assets/images/outline_arrow_drop_down_black_24pt_1x.png')
}